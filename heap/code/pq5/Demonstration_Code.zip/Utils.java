package com.company;

public class Utils {

    public static final int ClubTicket = 1;
    public static final int SeasonTicket = 2;
    public static final int OnlineTicket = 3;
    public static final int CounterTicket = 4;

}
