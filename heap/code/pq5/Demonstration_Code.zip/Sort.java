package com.company;

import java.lang.Comparable;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;

import static com.company.Utils.*;


public class Sort {

    public static void main(String[] args) {
        t1();
        t2();
    }

    public static void t1() {
        List<Integer> list = new ArrayList<Integer>();
        list.add(3);
        list.add(5);
        list.add(1);
        list.add(4);
        list.add(2);
        list.add(6);

        class DefaultComparator<T extends Comparable> implements Comparator<T> {

            public int compare(T o1, T o2) {
                return o1.compareTo(o2);
            }
        }


        MyPriorityQueue<Integer> pq = (MyPriorityQueue<Integer>) new ListPQ2<Integer>(new DefaultComparator());

        while(list.isEmpty() == false) {
            pq.add(list.remove(0));
        }

        while(pq.isEmpty() == false) {
            list.add(pq.removeMinimum());
        }
        for(Integer i : list) {
            System.out.println(i);
        }
        System.out.println("");
    }

    static class Ticket {
        public final String name;
        public final int ticketType;

        public Ticket(String name, int ticketType) {
            this.name = name;
            this.ticketType = ticketType;
        }

        public String toString() {
            return this.name;
        }
    }

    public static void t2() {
        List<Ticket> list = new ArrayList<Ticket>();
        list.add(new Ticket("Rachel", SeasonTicket));
        list.add(new Ticket("Joey", ClubTicket));
        list.add(new Ticket("Monica", OnlineTicket));
        list.add(new Ticket("Chandler", CounterTicket));
        list.add(new Ticket("Pheobe", SeasonTicket));
        list.add(new Ticket("Ross", CounterTicket));

        for(Ticket a : list) {
            System.out.println("Name: " + a.name + "    TicketType: " + a.ticketType);

        }
        System.out.println("");


        class TicketComparator<T extends Ticket> implements Comparator<T> {

            public int compare(T o1, T o2) {
                Ticket a1 = (Ticket) o1;
                Ticket a2 = (Ticket) o2;
                if(a1.ticketType < a2.ticketType) {
                    return -1;
                }
                else if(a1.ticketType > a2.ticketType) {
                    return 1;
                }
                else if(a1.ticketType == a2.ticketType) {
                    return -1;
                }
                else {
                    return 0;
                }
            }
        }


        MyPriorityQueue<Ticket> pq = (MyPriorityQueue<Ticket>) new ListPQ2<Ticket>(new TicketComparator<>());

        while(list.isEmpty() == false) {
            pq.add(list.remove(0));
        }

        while(pq.isEmpty() == false) {
            list.add(pq.removeMinimum());
        }
        for(Ticket a : list) {
            System.out.println(a);
        }
        System.out.println("");
    }


}
